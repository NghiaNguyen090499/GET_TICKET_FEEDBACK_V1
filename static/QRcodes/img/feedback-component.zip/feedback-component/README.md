# Feedback component

A Pen created on CodePen.io. Original URL: [https://codepen.io/jussivirtanen/pen/jOqWwxM](https://codepen.io/jussivirtanen/pen/jOqWwxM).

Lesson #5 of the free Full Stack UI course @ https://fullstackui.com

This time we'll build a smooth feedback component and get familiar with manipulating DOM element's height.